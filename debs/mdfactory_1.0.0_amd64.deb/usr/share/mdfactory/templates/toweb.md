---
from: markdown
highlight-style: haddock
number-sections: true
standalone: true
toc: true
toc-depth: 2
template: templates/webtemplate.html
css: css/style.css